# Databricks notebook source
dbutils.fs.ls("dbfs:/pipelines/0cc9df7a-e8fd-46c4-be2b-0095a9e584c4/checkpoints/")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`dbfs:/pipelines/0cc9df7a-e8fd-46c4-be2b-0095a9e584c4/system/events`

# COMMAND ----------

# MAGIC %sql
# MAGIC select details:flow_progress.soyrces
# MAGIC from system.events
# MAGIC where event_type = 'flow_progress'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from event_log("0cc9df7a-e8fd-46c4-be2b-0095a9e584c4")