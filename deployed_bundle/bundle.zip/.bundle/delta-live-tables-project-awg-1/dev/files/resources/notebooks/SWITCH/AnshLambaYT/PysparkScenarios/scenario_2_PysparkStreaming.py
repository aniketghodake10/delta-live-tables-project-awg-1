# Databricks notebook source
my_schema = """
order_id int,
customer_id int,
order_date date,
amount double
"""
df = spark.readStream.format('csv')\
    .option('header','true')\
        .schema(my_schema)\
            .load('/Volumes/pyspark_scenarios_catalog/source/db_volume/streamSource/')

# COMMAND ----------

df.writeStream.format('delta')\
    .option('checkpointLocation','/Volumes/pyspark_scenarios_catalog/source/db_volume/streamSink/_checkpoints')\
        .option('mergeSchema', True)\
            .trigger(once=True)\
            .start("/Volumes/pyspark_scenarios_catalog/source/db_volume/streamSink/data")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/pyspark_scenarios_catalog/source/db_volume/streamSink/data/`