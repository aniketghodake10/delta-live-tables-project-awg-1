# Databricks notebook source
spark

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %sql
# MAGIC truncate table delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/data`

# COMMAND ----------

# MAGIC %sql
# MAGIC -- BY DEFAULT - DELTA
# MAGIC create table pyspark_streaming_catalog.source.colors
# MAGIC (color string, eventtime timestamp)

# COMMAND ----------

# -- BY DEFAULT - DELTA
# create table pyspark_streaming_catalog.sink.colors_update_agg
# (start timestamp, end timestamp, color string, count int)
# using delta
# location "/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/data"

dfss = spark.createDataFrame([], """
start timestamp, end timestamp, color string, count long""")
dfss.write.format("delta").mode("overwrite").save("/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/data")

# COMMAND ----------

df = spark.readStream.table('pyspark_streaming_catalog.source.colors')\
           .withWatermark("eventtime", "30 minutes")
df.createOrReplaceTempView("df_readStream")

# COMMAND ----------

df = df.groupBy(window("eventtime", "5 minutes"), "color").agg(count("*").alias("count")).select("window.start", "window.end", "color", "count")

# COMMAND ----------

df.writeStream.format("delta")\
    .outputMode("append")\
    .option("checkpointLocation", "/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/1/checkpoint")\
        .trigger(once=True)\
    .start("/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/1/data")

# COMMAND ----------

from delta.tables import DeltaTable

delta_tbl_obj = DeltaTable.forPath(spark, '/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/data')

def foreachbatch_method(dfsrc, epochId):
    dfsrc.createOrReplaceTempView("dfsrc_foreachbatch")
    delta_tbl_obj.alias('trg').merge(
        dfsrc.alias('src'),
        'trg.start = src.start and trg.end = src.end and trg.color = src.color'
    ).whenMatchedUpdate(set = {"count":"trg.count+src.count"})\
        .whenNotMatchedInsertAll(condition="current_timestamp() > (src.end+INTERVAL '30 minutes')").execute()

df.writeStream.format("delta")\
    .outputMode("update")\
        .foreachBatch(foreachbatch_method)\
    .option("checkpointLocation", "/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/checkpoint")\
        .trigger(once=True)\
    .start()

# COMMAND ----------

df.writeStream.format("delta")\
    .outputMode("complete")\
    .option("checkpointLocation", "/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/3/checkpoint")\
        .trigger(once=True)\
    .start("/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/3/data")

# COMMAND ----------

df.writeStream.format("memory")\
    .queryName("update_memory")\
    .outputMode("update")\
    .start()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/1/data`
# MAGIC order by start

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/data`
# MAGIC order by start

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/3/data`
# MAGIC order by start

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/1/data`

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/3/data`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dfsrc_foreachbatch

# COMMAND ----------

df = spark.sql("select * from delta.`/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/1/data`")
df.printSchema()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from df_readStream

# COMMAND ----------

display(df, checkpointLocation = "/Volumes/pyspark_streaming_catalog/sink/streaming_sink_volume/dir9SEP/2/checkpoint")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from update_memory order by start