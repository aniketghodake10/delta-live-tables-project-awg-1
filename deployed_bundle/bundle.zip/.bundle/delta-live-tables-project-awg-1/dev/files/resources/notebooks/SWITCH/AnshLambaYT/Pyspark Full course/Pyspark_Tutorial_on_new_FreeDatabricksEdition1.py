# Databricks notebook source
# MAGIC %md
# MAGIC # DATA READING

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Reading JSON

# COMMAND ----------

df_json = spark.read.format("json")\
    .options(header='true', inferSchema='true', multiline='true')\
    .load("/Volumes/workspace/default/rebuild_volume1/drivers.json")


# COMMAND ----------

df_json.printSchema()
df_json.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Reading Utils

# COMMAND ----------

dbutils.fs.ls("/Volumes/workspace/default/rebuild_volume1/")

# COMMAND ----------

df = spark.read.format('csv')\
    .options(header='true', inferSchema='true')\
    .load("/Volumes/workspace/default/rebuild_volume1/BigMart Sales.csv")

# COMMAND ----------

#df.display()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schema Definition
# MAGIC ### 1) DDL SCHEMA
# MAGIC ### 2) StructType() SCHEMA

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import  *

# COMMAND ----------

my_ddl_schema = '''
                    Item_Identifier STRING,
                    Item_Weight STRING,
                    Item_Fat_Content STRING, 
                    Item_Visibility DOUBLE,
                    Item_Type STRING,
                    Item_MRP DOUBLE,
                    Outlet_Identifier STRING,
                    Outlet_Establishment_Year INT,
                    Outlet_Size STRING,
                    Outlet_Location_Type STRING, 
                    Outlet_Type STRING,
                    Item_Outlet_Sales DOUBLE 

                ''' 

my_struct_schema = StructType([
                    StructField('Item_Identifier', StringType(), True),
                    StructField('Item_Weight', StringType(), True),
                    StructField('Item_Fat_Content', StringType(), True),
                    StructField('Item_Visibility', DoubleType(), True),
                    StructField('Item_Type', StringType(), True),
                    StructField('Item_MRP', DoubleType(), True),
                    StructField('Outlet_Identifier', StringType(), True),
                    StructField('Outlet_Establishment_Year', IntegerType(), True),
                    StructField('Outlet_Size', StringType(), True),
                    StructField('Outlet_Location_Type', StringType(), True),
                    StructField('Outlet_Type', StringType(), True),
                    StructField('Item_Outlet_Sales', DoubleType(), True)
                ])

# COMMAND ----------

df = spark.read.format('csv')\
    .options(header='true')\
        .schema(my_ddl_schema)\
    .load("/Volumes/workspace/default/rebuild_volume1/BigMart Sales.csv")

# COMMAND ----------

# df.printSchema()
# df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # TRANSFORMATIONS

# COMMAND ----------

# MAGIC %md
# MAGIC ### SELECT, ALIAS

# COMMAND ----------

df.select(col('Item_Identifier'), col("Item_Weight"))

# COMMAND ----------

df.select(col('Item_Identifier').alias('Aniket_Item_Identifier')).show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## FILTER

# COMMAND ----------

df.filter((col('Item_Identifier').contains('FD')) & (col('Outlet_Location_Type').isin('Tier 1','Tier 2'))).show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## withColumnRenamed

# COMMAND ----------

df.withColumnRenamed('Item_Identifier','Aniket_Item_Identifier').show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### withColumn

# COMMAND ----------

df.withColumn('flag', lit('new_test_column')).show(2)

# COMMAND ----------

df.withColumn('Item_Identifier', regexp_replace(col('Item_Identifier'), 'FD', 'fd')).show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Typecasting

# COMMAND ----------

df.withColumn('Item_Weight',col('Item_Weight').cast(DoubleType())).show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC # SORT

# COMMAND ----------

df.sort(col('Item_Weight').desc()).show(2)

# COMMAND ----------

df.sort(['Item_Weight', 'Item_MRP'], descending=[True, False]).show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## LIMIT

# COMMAND ----------

# df.limit(10).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## DROP, dropDuplicates, drop_duplicates, distinct

# COMMAND ----------

df.drop(col('Item_Visibility'), col('Item_Identifier')).show(2)
# df.dropDuplicates().display()
# df.drop_duplicates(subset=['Item_Type']).display() # same as dropDuplicates, just Pandas APi
# df.distinct().display() # cannot use subset feature