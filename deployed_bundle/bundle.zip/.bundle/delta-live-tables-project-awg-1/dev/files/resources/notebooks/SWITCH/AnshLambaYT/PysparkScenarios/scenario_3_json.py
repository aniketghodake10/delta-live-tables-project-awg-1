# Databricks notebook source
df = spark.read.format('json').option('multiline','true')\
          .option('inferSchema','true')\
          .load("/Volumes/pyspark_scenarios_catalog/source/db_volume/jsonData/")

# COMMAND ----------

df.printSchema()

# COMMAND ----------

display(df)

# COMMAND ----------

df_cust = df.select("customer.*", "customer.location.city")
display(df_cust)

# COMMAND ----------

from pyspark.sql.functions import explode
df_explode = df.withColumn('delivery_updates', explode("delivery_updates"))
display(df_explode)