# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE workspace.stream.windowtbl
# MAGIC (
# MAGIC   color STRING,
# MAGIC   event_date TIMESTAMP
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO workspace.stream.windowtbl
# MAGIC VALUES
# MAGIC ('red','2025-01-01T11:07:00.000+00:00')

# COMMAND ----------

df = spark.readStream.table("workspace.stream.windowtbl")

# COMMAND ----------

from pyspark.sql.functions import * 

# COMMAND ----------

df = df.groupBy("color",window("event_date","10 minutes"))\
            .agg(count(lit(1)).alias("color_count"))

# COMMAND ----------

df.writeStream.format("delta")\
        .outputMode("complete")\
        .trigger(once=True)\
        .option("path","/Volumes/workspace/stream/streaming/windows/Data")\
        .option("checkpointLocation","/Volumes/workspace/stream/streaming/windows/checkpoint")\
        .start()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta.`/Volumes/workspace/stream/streaming/windows/Data`

# COMMAND ----------

