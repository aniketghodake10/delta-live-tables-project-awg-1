-- Databricks notebook source
--SELECT * from workspace.default.big_mart_sales limit 10;


--INSERT INTO Customers (CustomerName, ContactName) VALUES ('Cardinal', 'Tom B. Erichsen');
--UPDATE table_name SET column1 = value1, column2 = value2, ...WHERE condition;
--DELETE FROM table_name WHERE condition;.....table will not be deleted
--DROP TABLE Customers;


-- ORDER BY fields need to be SELECTED first........be defuallt - ASC


/* Precedence Rules - Parentheses () >> NOT >> AND >> ALL, ANY, SOME >> OR
                      FROM/JOIN >> WHERE >> GROUP BY >> HAVING >> SELECT DISTINCT >> ORDER BY >> LIMIT
*/


/* Aggregate Functions - AVG, SUM, COUNT, MAX, MIN
                         Aggregate functions ignore null values (except for COUNT(*))
                         COUNT(*) → counts all rows, including those with NULL
                         COUNT(column) → counts non-NULL values only.
                         COUNT(DISTINCT column) - counts unique non-NULL values only
                         expression inside SUM - SELECT SUM(Price * Quantity) FROM OrderDetails;
                         AVG - NULL values are ignored.
*/


/* LIKE - % - 0 or more chars, underscore - exactly 1 char, [AB] - 1 char - either A or B, [^AB] - 1 char - nither A nor B
          WHERE description LIKE '%100!%%' ESCAPE '!';.....any char can be defined as escape char
*/


--WHERE CustomerID IN (SELECT CustomerID FROM Orders);
--SELECT name, salary FROM employees WHERE salary = (SELECT MAX(salary)FROM employees);


--The BETWEEN operator is inclusive: begin and end values are included.


/* JOIN - INNER JOIN - default join type for JOIN (we can just use JOIN instead of INNER JOIN)
          LEFT JOIN, RIGHT JOIN, FULL JOIN (we can skip to write OUTER)
*/


-- UNION - distinct, UNION ALL - all values


--EXTSTS - returns TRUE if the subquery returns one or more records.


/* ANY, ALL.......just use MAX, MIN instead
--Find employees whose salary is greater than ANY salary in department 10
SELECT name, salary
FROM employees
WHERE salary > ANY (
    SELECT salary
    FROM employees
    WHERE dept_id = 10
);
-- Find employees whose salary is greater than ALL salaries in department 10
SELECT name, salary
FROM employees
WHERE salary > ALL (
    SELECT salary
    FROM employees
    WHERE dept_id = 10
);
-- using MAX
SELECT name, salary
FROM employees
WHERE salary > (
    SELECT MAX(salary)
    FROM employees
    WHERE dept_id = 10
);
*/


/* SELECT INTO - copies data from one table into a new table. CREATES NEW TABLE
                 if table already exists, it will give ERROR
                 SELECT INTO can also be used to create a new, empty table using the schema of another.
                 Just add a WHERE clause that causes the query to return no data:
                 SELECT * INTO newtable FROM oldtable WHERE 1 = 0;
*/


--INSERT INTO SELECT statement copies data from one table and inserts it into another table.


--ISNULL(col, VALUE), NVL(col, VALUE), 
-- select coalesce(Outlet_Size, )


/*
--A stored procedure is a prepared SQL code that you can save, so the code can be reused over and over again.

CREATE PROCEDURE SelectAllCustomers @City nvarchar(30), @PostalCode nvarchar(10)
AS
SELECT * FROM Customers WHERE City = @City AND PostalCode = @PostalCode
GO;

EXEC SelectAllCustomers @City = 'London', @PostalCode = 'WA1 1DP';
*/


/*
--SQL DATABASE

CREATE DATABASE databasename;
DROP DATABASE testDB;
BACKUP DATABASE testDB TO DISK = 'D:\backups\testDB.bak' WITH DIFFERENTIAL;

CREATE TABLE Persons (
    PersonID int,
    LastName varchar(255),
    FirstName varchar(255),
    Address varchar(255),
    City varchar(255)
);
CREATE TABLE TestTable AS
SELECT customername, contactname
FROM customers;

DROP TABLE table_name;
TRUNCATE TABLE table_name;......delete the data inside a table, but not the table itself.

--ALTER TABLE statement is used to add, delete, or modify columns in an existing table.
--ALTER TABLE statement is also used to add and drop various constraints on an existing table.
ALTER TABLE table_name ADD column_name datatype;
ALTER TABLE table_name DROP COLUMN column_name;
ALTER TABLE table_name RENAME COLUMN old_name to new_name;
ALTER TABLE table_name ALTER COLUMN column_name datatype; OR MODIFY COLUMN (oracle)

--CONSTRAINTS - specify rules for data in a table. 
                1)column level 2)table level
                while CREATE TABLE, ALTER TABLE
NOT NULL, UNIQUE, 
PRIMARY KEY - NOT NULL+UNIQUE....uniquely identifies record, data integrity
FOREIGN KEY - prevent actions that would destroy links between tables
              a field (or collection of fields) in one table, that refers to the PRIMARY KEY in another table.
CHECK, DEFAULT
INDEX - used to create indexes in tables, speed up querying, but updating takes longer time  as need to update index also
        CREATE INDEX index_name ON table_name (column1, column2, ...);....DROP INDEX index_name
CREATE TABLE table_name (
    column1 datatype constraint_type,
    column2 datatype constraint_type,
    column3 datatype constraint_type,
    CONSTRAINT UC_Person UNIQUE (ID,LastName),
    PRIMARY KEY (OrderID),
    FOREIGN KEY (PersonID) REFERENCES Persons(PersonID),
    Age int CHECK (Age>=18),
    CONSTRAINT CHK_Person CHECK (Age>=18 AND City='Sandnes'),
    City varchar(255) DEFAULT 'Sandnes'
);
ALTER TABLE table_name ADD CONSTRAINT constraint_name constraint_type (column_name);
ALTER TABLE table_name DROP CONSTRAINT constraint_name constraint_type (column_name);
ALTER TABLE table_name ALTER COLUMN column_name datatype constraint_type;

--AUTO_INCREMENT, IDENTITY(1,1)...starts from 1, increment by 1
*/


/*
--DATE, TIME, DATETIME, TIMESTAMP, INTERVAL

--SQL Server (there is no data format in SQL Server.....u just display it differently)
GETDATE(), DATEADD(), DATEDIFF()
FORMAT(OrderDate, 'yyyy-MM-dd')….converts to string
CONVERT(,,120)...use style codes
CAST(date_col as DATETIME)
To Truncate date column - CAST(date_col as DATE)
SELECT DATEADD(day, 7, GETDATE());......SELECT DATEADD(month, 3, '2025-01-15');
SELECT DATEDIFF(year, '2020-05-01', GETDATE());
SELECT DATEDIFF(DAY, GETDATE(), DATEADD(day, 1, GETDATE())) from workspace.default.big_mart_sales;
select DATEPART('YEAR', GETDATE()),
    DATEPART('WEEK', GETDATE())
    --,
    --DATENAME('MONTH', GETDATE()),
    --DATENAME('WEEKDAY', GETDATE()) 
    from workspace.default.big_mart_sales;
SELECT CAST(GETDATE() AS DATE) from workspace.default.big_mart_sales;
*/


--CREATE OR REPLACE VIEW [Brazil Customers] AS SELECT CustomerName, ContactName, City FROM Customers WHERE Country = 'Brazil';
--DROP VIEW [Brazil Customers]


/*
--SQL Injection - placement of malicious code in SQL statements, via web page input.
txtUserId = getRequestString("UserId");
txtSQL = "SELECT * FROM Users WHERE UserId = " + txtUserId;
user inputs "105 OR 1=1"

To avoid this parameters
txtNam = getRequestString("CustomerName");
txtAdd = getRequestString("Address");
txtCit = getRequestString("City");
txtSQL = "INSERT INTO Customers (CustomerName,Address,City) Values(@0,@1,@2)";
db.Execute(txtSQL,txtNam,txtAdd,txtCit);
*/


/*
--SQL Server Data types
char(n) - fixed length, if not it fills spaces automatically
varchar(n)
nvarchar(n) - Unicode string
text
BOOLEAN
INT(n), BIGINT(n), FLOAT(n,d), DOUBLE(n,d)
DATE, TIME, DATETIME
*/


/*
--WINDOW FUNCTIONS
ROW_NUMBER()	                Assigns a unique sequential number to rows within a partition.  1,2,3,4,5,6
RANK()	                        Assigns a rank to each row, with gaps for ties. 1,1,1,4,4,6,6
DENSE_RANK()	                Similar to RANK(), but no gaps in ranking. 1,1,1,2,2,3,3
NTILE(n)	                Divides rows into n roughly equal groups.
LEAD()	                        Accesses data from the next row.
LAG()	                        Accesses data from the previous row.
FIRST_VALUE()	                Returns the first value in the window frame.
LAST_VALUE()	                Returns the last value in the window frame.
SUM(), AVG(), MIN(), MAX()	Can be used as windowed aggregates.

SELECT EmployeeID,Department,Salary,
    RANK() OVER (PARTITION BY Department ORDER BY Salary DESC) AS SalaryRank
FROM Employees;

LAG(Amount, offset, default value) OVER (ORDER BY SaleDate) AS PreviousDayAmount,
LEAD(Amount, 1, 0) OVER (ORDER BY SaleDate) AS NextDayAmount

--Below terms - work under partition....if partition by not used, it will work under whole column
CURRENT ROW, UNBOUNDED PRECEDING, UNBOUNDED FOLLOWING, n PRECEDING AND n FOLLOWING
ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING

--partition by and order by - somewhere mandatory and somewhere not....based on function used
*/


