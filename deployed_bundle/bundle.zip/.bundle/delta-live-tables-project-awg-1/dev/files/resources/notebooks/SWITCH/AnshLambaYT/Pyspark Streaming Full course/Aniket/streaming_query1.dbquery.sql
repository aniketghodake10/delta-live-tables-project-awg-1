-- Databricks notebook source
#TEST
INSERT INTO colors (color, eventtime) VALUES
('red', current_timestamp());

INSERT INTO colors (color, eventtime) VALUES
('red', timestamp("2025-09-09T13:59:32.648"));

INSERT INTO colors (color, eventtime) VALUES
('red', (current_timestamp() - INTERVAL 1 MINUTE));

INSERT INTO colors (color, eventtime) VALUES
('red', current_timestamp()),
('red', current_timestamp());

INSERT INTO colors (color, eventtime) 
select * from colors order by eventtime desc limit 1;

select * from colors order by eventtime

truncate table colors

